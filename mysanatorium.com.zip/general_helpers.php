<?php

use App\Models\CreditCards;
use App\Models\RoutesModel;
use App\Models\RouteLines;
use App\Models\TransferCompanies;
use App\Models\SmbElements;
use App\Models\Sd;
use App\Models\Sws;
use App\Models\DiscountOptions;
use App\Models\RoomKinds;
use App\Models\Sanatoriums;
use App\Models\Stchild;
use App\Models\Stoutchild;
use Illuminate\Support\Carbon;
use Carbon\CarbonPeriod;

function countRoutesByCountry($country_id)
{
    $data = RoutesModel::where('country_id', $country_id)->count();
    return $data;
}

function countRouteLinesByCompany($company_id)
{
    $data = RouteLines::where('transfer_company_id', $company_id)->count();
    return $data;
}

function getRouteLinesLocation($id)
{
    $from = RoutesModel::where('id', $id)->first();
    return $from['address'];
}

function getTransferCompanyCurrencySymbol($id)
{
    $company = TransferCompanies::where('id', $id)->first();
    $symbol = $company->getCurrency['code'];

    return $symbol;
}

function check_available($sanatorium_id, $medical_base_id)
{
    $medical_base_id = SmbElements::where('sanatoriums_id', $sanatorium_id)->where('medical_base_elements_id', $medical_base_id)->first();
    if (isset($medical_base_id)) {
        return "yes";
    } else {
        return "no";
    }
}

function check_discount_available($sanatorium_id, $discount_id)
{
    $discount = Sd::where('sanatoriums_id', $sanatorium_id)->where('discounts_id', $discount_id)->first();
    if (isset($discount)) {
        return "yes";
    } else {
        return "no";
    }
}

function gdo($discount_id, $option_element_name)
{
    $options = DiscountOptions::where('discounts_id', $discount_id)->first();
    if (isset($options)) {
        return $options[$option_element_name];
    } else {
        return '';
    }
}

function getCreditCardInfo($card_id)
{
    $card_data = CreditCards::find($card_id);
    return $card_data['name'];
}

function getRoomName($id)
{
    $room_name = RoomKinds::find($id);
    return $room_name['name'];
}

function check_w_or_d($sanatorium_id)
{
    $sws = Sws::where('sanatoriums_id', $sanatorium_id)->first();
    if (!empty($sws)) {
        return $sws->w_or_d;
    } else {
        return 0;
    }
}

function child_is_accepted($sanatorium_id)
{
    $child = Stchild::where('sanatoriums_id', $sanatorium_id)->first();
    if (!empty($child)) {
        return $child->child_id_accepted;
    } else {
        return '';
    }
}

function out_child_is_accepted($sanatorium_id)
{
    $child = Stoutchild::where('sanatoriums_id', $sanatorium_id)->first();
    if (!empty($child)) {
        return $child->out_child_id_accepted;
    } else {
        return '';
    }
}

function calendar()
{
    $ranges = CarbonPeriod::create(Carbon::now(), Carbon::now()->addMonthsWithNoOverflow(2));
    
    $html = "";
    foreach($ranges as $range )
    {
        $html .= "<td>";
        $html .= "<strong><span class='days'>".$range->day."</span>&nbsp;";
        $html .= "<span class='months'>".$range->format('F')."</span></strong><br>";
        $html .= "<small class='days_name'>".$range->format('l')."</small>";
        $html .= "</td>";
    }
    echo $html;

}

function wizart_optional($sanatorium_id)
{
    

}