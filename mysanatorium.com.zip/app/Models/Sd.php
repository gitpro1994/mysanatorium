<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Sd extends Model
{
    use HasFactory;

    protected $table = 'sds';
    protected $fillable = ['sanatoriums_id', 'discounts_id'];
}
