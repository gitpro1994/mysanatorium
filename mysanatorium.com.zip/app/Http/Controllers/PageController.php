<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller
{
    public function welcome()
    {
        return view('frontend.welcome');
    }

    public function about()
    {
        return view('frontend.header.about.about');
    }

    public function team()
    {
        return view('frontend.header.about.team');
    }

    public function faq()
    {
        return view('frontend.header.about.faq');
    }

    public function contact()
    {
        return view('frontend.header.about.contact');
    }

    public function treaty()
    {
        return view('frontend.header.about.treaty');
    }

    public function choose_right_resort()
    {
        return view('frontend.header.choose_right_resort');
    }

    public function balneology_consultation()
    {
        return view('frontend.haeder.balneology_consultation');
    }

    public function visa_support()
    {
        return view('frontend.header.visa_support');
    }

    public function transfer()
    {
        return view('frontend.header.transfer');
    }

    public function treatment_specialization($id)
    {
        return view('frontend.treatment_specialization');
    }
}
