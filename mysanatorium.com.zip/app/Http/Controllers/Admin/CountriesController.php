<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Countries;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class CountriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['countries'] = Countries::all();
        $data['deleted'] = Countries::onlyTrashed()->count();
        return view('admin.countries.index', $data);
    }

    public function deleted_countries()
    {
        $data['countries'] = Countries::onlyTrashed()->get();
        return view('admin.countries.deleted', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('admin.countries.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validation = Validator::make($request->all(),[
            'slug' => 'required',
            'title' => 'required',
            'search_title' => 'required',
            'shortened' => 'required',
            'meta_titul' => 'required',
            'meta_description' => 'required',
            'meta_keywords' => 'required',
            'meta_H1' => 'required',
            'country_number_prefix' => 'required',
        ]);

        if ($validation->fails())
        {
            return redirect()->back()->withErrors($validation);
        }
        $countries = new Countries();
        $countries->slug = Str::slug($request->slug);
        $countries->title = $request->title;
        $countries->search_title = $request->search_title;
        $countries->shortened = $request->shortened;
        $countries->meta_titul = $request->meta_titul;
        $countries->meta_description = $request->meta_description;
        $countries->meta_keywords = $request->meta_keywords;
        $countries->meta_H1 = $request->meta_H1;
        $countries->country_number_prefix = $request->country_number_prefix;
        if($request->for_sanatorium == "on")
        {
            $countries->for_sanatorium = 1;
        }
        else
        {
            $countries->for_sanatorium = 0;
        }

        if($request->hasFile('flag')){
            /* get File from Request */
            $file = $request->file('flag');
            /* get File Extension */
            $extension = $file->getClientOriginalExtension();
            /* Your File Destination */
            $destination = 'backend/images/flags/';
            /* unique Name for file */
            $filename = uniqid() . '.' . $extension;
            /* finally move file to your destination */
            $file->move($destination, $filename);
            $countries->flag = $filename;
        };
        $countries->status = 1;
        $countries->save();
        return redirect()->route('admin.countries')->with('success','Məlumatlar daxil edildi!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $data['country'] = Countries::find($id);
       return view('admin.countries.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $validation = Validator::make($request->all(),[
            'slug' => 'required',
            'title' => 'required',
            'search_title' => 'required',
            'shortened' => 'required',
            'meta_titul' => 'required',
            'meta_description' => 'required',
            'meta_keywords' => 'required',
            'meta_H1' => 'required',
            'country_number_prefix' => 'required',
        ]);

        if ($validation->fails())
        {
            return redirect()->back()->withErrors($validation);
        }
        else
        {
            $countries = Countries::find($id);
            $countries->slug = Str::slug($request->slug);
            $countries->title = $request->title;
            $countries->search_title = $request->search_title;
            $countries->shortened = $request->shortened;
            $countries->meta_titul = $request->meta_titul;
            $countries->meta_description = $request->meta_description;
            $countries->meta_keywords = $request->meta_keywords;
            $countries->meta_H1 = $request->meta_H1;
            $countries->country_number_prefix = $request->country_number_prefix;
            if($request->for_sanatorium == "on")
            {
                $countries->for_sanatorium = 1;
            }
            else
            {
                $countries->for_sanatorium = 0;
            }

            if($request->hasFile('flag')){
                /* get File from Request */
                $file = $request->file('flag');
                /* get File Extension */
                $extension = $file->getClientOriginalExtension();
                /* Your File Destination */
                $destination = 'backend/images/flags/';
                /* unique Name for file */
                $filename = uniqid() . '.' . $extension;
                /* finally move file to your destination */
                $file->move($destination, $filename);
                $countries->flag = $filename;
            };
            $countries->status = 1;
            $countries->save();
            return redirect()->route('admin.countries')->with('success','Məlumatlar dəyişdirildi!');
        }
    }

    public function restore($id)
    {
        Countries::withTrashed()->find($id)->restore();
        return redirect()->back()->with('success', 'Məlumat geri qaytarıldı!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $country = Countries::find($id);
        $country->delete();
        return redirect()->route('admin.countries')->with('success','Məlumatlar silindi!');
    }

    public function check_status($id)
    {
        $country = Countries::find($id);
        if($country['status'] == 1)
        {
            $country->status = 0;
        }
        else
        {
            $country->status = 1;
        }
        $country->save();

        return "Status dəyişdirildi!";
    }
}
