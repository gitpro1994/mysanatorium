<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\{Cities,
    Company,
    Countries,
    CreditCards,
    Currencies,
    Discounts,
    MedicalBase,
    MedicalBaseElements,
    Penalties,
    RoomKinds,
    Sanatorium_MedicalBases,
    Sanatoriums,
    Sd,
    SmbElements,
    DiscountOptions,
    Srk,
    SrkOptions,
    RoomConditions,
    Sccs,
    Stchild,
    Stoutchild,
    Sws};
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class SanatoriumsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['sanatoriums'] = Sanatoriums::all();
        return view('admin.sanatoriums.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['credit_cards'] = CreditCards::where('status', 1)->get();
        $data['countries'] = Countries::where('status', 1)->where('for_sanatorium', 1)->get();
        $data['companies'] = Company::where('status', 1)->get();
        $data['currencies'] = Currencies::where('status', 1)->get();
        return view('admin.sanatoriums.create', $data);
    }

    public function getCities($country_id)
    {
        $cities = Cities::where('country_id', $country_id)->where('status', 1)->get();
        $companies = Company::where('country_id', $country_id)->where('status', 1)->get();
        $html_response['cities'] = '';
        $html_response['companies'] = '';
        foreach ($cities as $city) {
            $html_response['cities'] .= '<option value="' . $city->id . '">' . $city->title . '</option>';
        }

        foreach ($companies as $company) {
            $html_response['companies'] .= '<option value="' . $company->id . '">' . $company->name . '</option>';
        }
        return $html_response;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {

        $sanatoriums = new Sanatoriums();
        $sanatoriums->name = $request->name;
        $sanatoriums->search_title = $request->search_title;
        $sanatoriums->meta_title = $request->meta_title;
        $sanatoriums->meta_description = $request->meta_description;
        $sanatoriums->meta_keywords = $request->meta_keywords;
        $sanatoriums->meta_H1 = $request->meta_H1;
        $sanatoriums->slug = $request->slug;
        $sanatoriums->address = $request->address;
        $sanatoriums->currency_id = $request->currency_id;
        $sanatoriums->youtube_video_link = $request->youtube_video_link;
        $sanatoriums->bron_email = $request->bron_email;
        $sanatoriums->rate = $request->rate;
        $sanatoriums->country_id = $request->country_id;
        $sanatoriums->city_id = $request->city_id;
        $sanatoriums->company_id = $request->company_id;
        $sanatoriums->phone_number = $request->phone_number;
        $sanatoriums->map = $request->map;
        $sanatoriums->_3d_map = $request->_3d_map;
        $sanatoriums->latitude = $request->latitude;
        $sanatoriums->longitude = $request->longitude;
        $sanatoriums->tax_price = $request->tax_price;
        $sanatoriums->transfer_link = $request->transfer_link;

        $sanatoriums->number_of_staff = ($request->number_of_staff == "on") ? 1 : 0;
        $sanatoriums->tax_included = ($request->tax_included == "on") ? 1 : 0;
        $sanatoriums->transfer_included = ($request->transfer_included == "on") ? 1 : 0;

        $sanatoriums->main_description = $request->main_description;
        $sanatoriums->reservation_rules = $request->reservation_rules;
        $sanatoriums->payment_rules = $request->payment_rules;
        $sanatoriums->reservation_contract = $request->reservation_contract;
        $sanatoriums->advantages = $request->advantages;
        $sanatoriums->important_to_know = $request->important_to_know;
        $sanatoriums->treatment_package_price = $request->treatment_package_price;
        $sanatoriums->paid_medical_procedures = $request->paid_medical_procedures;
        $sanatoriums->check_in_for_adults = $request->check_in_for_adults;
        $sanatoriums->check_in_for_children = $request->check_in_for_children;


        if ($request->file('main_image')) {
            $file = $request->file('main_image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('backend/images/sanatoriums'), $filename);
            $sanatoriums->main_image = $filename;
        }

        if ($request->file('second_image')) {
            $file = $request->file('second_image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('backend/images/sanatoriums'), $filename);
            $sanatoriums->second_image = $filename;
        }

        if ($request->file('youtube_image')) {
            $file = $request->file('youtube_image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('backend/images/sanatoriums'), $filename);
            $sanatoriums->youtube_image = $filename;
        }
        $sanatoriums->status = 1;
        $sanatoriums->save();
        return redirect()->route('admin.sanatoriums')->with('success', 'Məlumatlar əlavə edildi!');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $data['credit_cards'] = CreditCards::where('status', 1)->get();
        $data['countries'] = Countries::where('status', 1)->where('for_sanatorium', 1)->get();
        $data['cities'] = Cities::where('status', 1)->get();
        $data['companies'] = Company::where('status', 1)->get();
        $data['currencies'] = Currencies::where('status', 1)->get();
        $data['sanatorium'] = Sanatoriums::find($id);
        return view('admin.sanatoriums.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $sanatoriums = Sanatoriums::find($id);
        $sanatoriums->name = $request->name;
        $sanatoriums->search_title = $request->search_title;
        $sanatoriums->meta_title = $request->meta_title;
        $sanatoriums->meta_description = $request->meta_description;
        $sanatoriums->meta_keywords = $request->meta_keywords;
        $sanatoriums->meta_H1 = $request->meta_H1;
        $sanatoriums->slug = $request->slug;
        $sanatoriums->address = $request->address;
        $sanatoriums->currency_id = $request->currency_id;
        $sanatoriums->youtube_video_link = $request->youtube_video_link;
        $sanatoriums->bron_email = $request->bron_email;
        $sanatoriums->rate = $request->rate;
        $sanatoriums->country_id = $request->country_id;
        $sanatoriums->city_id = $request->city_id;
        $sanatoriums->company_id = $request->company_id;
        $sanatoriums->phone_number = $request->phone_number;
        $sanatoriums->map = $request->map;
        $sanatoriums->_3d_map = $request->_3d_map;
        $sanatoriums->latitude = $request->latitude;
        $sanatoriums->longitude = $request->longitude;
        $sanatoriums->tax_price = $request->tax_price;
        $sanatoriums->transfer_link = $request->transfer_link;
        $sanatoriums->credit_cards = json_encode($request->credit_cards);

        $sanatoriums->credit_card_important = ($request->credit_card_important == "on") ? 1 : 0;
        $sanatoriums->cvv_card_booking = ($request->cvv_card_booking == "on") ? 1 : 0;
        $sanatoriums->number_of_staff = ($request->number_of_staff == "on") ? 1 : 0;
        $sanatoriums->tax_included = ($request->tax_included == "on") ? 1 : 0;
        $sanatoriums->transfer_included = ($request->transfer_included == "on") ? 1 : 0;

        $sanatoriums->main_description = $request->main_description;
        $sanatoriums->reservation_rules = $request->reservation_rules;
        $sanatoriums->payment_rules = $request->payment_rules;
        $sanatoriums->reservation_contract = $request->reservation_contract;
        $sanatoriums->advantages = $request->advantages;
        $sanatoriums->important_to_know = $request->important_to_know;
        $sanatoriums->treatment_package_price = $request->treatment_package_price;
        $sanatoriums->paid_medical_procedures = $request->paid_medical_procedures;
        $sanatoriums->check_in_for_adults = $request->check_in_for_adults;
        $sanatoriums->check_in_for_children = $request->check_in_for_children;


        if ($request->has('main_image')) {
            if ($request->file('main_image')) {
                $file = $request->file('main_image');
                $filename = date('YmdHi') . $file->getClientOriginalName();
                $file->move(public_path('backend/images/sanatoriums'), $filename);
                $sanatoriums->main_image = $filename;
            }
        }

        if ($request->has('second_image')) {
            if ($request->file('second_image')) {
                $file = $request->file('second_image');
                $filename = date('YmdHi') . $file->getClientOriginalName();
                $file->move(public_path('backend/images/sanatoriums'), $filename);
                $sanatoriums->second_image = $filename;
            }
        }

        if ($request->has('youtube_image')) {
            if ($request->file('youtube_image')) {
                $file = $request->file('youtube_image');
                $filename = date('YmdHi') . $file->getClientOriginalName();
                $file->move(public_path('backend/images/sanatoriums'), $filename);
                $sanatoriums->youtube_image = $filename;
            }
        }

        $sanatoriums->status = 1;
        $sanatoriums->save();
        return redirect()->route('admin.sanatoriums')->with('success', 'Məlumatlar dəyişdirildi!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        Sanatoriums::find($id)->delete();
        return redirect()->back()->with('success', 'Məlumatlar silindi!');
    }

    public function restore($id)
    {
        Sanatoriums::withTrashed()->find($id)->restore();
        return redirect()->back()->with('success', 'Məlumat geri qaytarıldı!');
    }

    public function deleted_sanatoriums()
    {
        $data['sanatoriums'] = Sanatoriums::onlyTrashed()->get();
        return view('admin.sanatoriums.deleted', $data);
    }

    public function check_status($id)
    {
        $city = Sanatoriums::find($id);
        if ($city['status'] == 1) {
            $city->status = 0;
        } else {
            $city->status = 1;
        }
        $city->save();

        return "Status dəyişdirildi!";
    }

    public function upload(Request $request)
    {
        if ($request->hasFile('upload')) {
            $originName = $request->file('upload')->getClientOriginalName();
            $fileName = pathinfo($originName, PATHINFO_FILENAME);
            $extension = $request->file('upload')->getClientOriginalExtension();
            $fileName = $fileName . '_' . time() . '.' . $extension;

            $request->file('upload')->move(public_path('backend/images/sanatoriums'), $fileName);

            $CKEditorFuncNum = $request->input('CKEditorFuncNum');
            $url = asset('backend/images/sanatoriums' . $fileName);
            $msg = 'Image uploaded successfully';
            $response = "<script>window.parent.CKEDITOR.tools.callFunction($CKEditorFuncNum, '$url', '$msg')</script>";

            @header('Content-type: text/html; charset=utf-8');
            echo $response;
        }
    }

    public function discount($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::find($sanatorium_id);
        $data['discount_options'] = DiscountOptions::where('sanatoriums_id', $sanatorium_id)->get();
        return view('admin.sanatoriums.properties.discount.discount', $data);
    }

    public function doc($sanatorium_id)
    {
        $data['discounts'] = Discounts::where('status', 1)->get();
        $data['sanatorium'] = Sanatoriums::find($sanatorium_id);
        $data['room_kinds'] = RoomKinds::where('status', 1)->get();
        return view('admin.sanatoriums.properties.discount.create-discount', $data);
    }

    public function room_kinds($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::where('id', $sanatorium_id)->first();
        $data['sanatorium_room_kinds'] = Srk::where('sanatoriums_id', $sanatorium_id)->get();
        return view('admin.sanatoriums.properties.room-kinds.room-kinds', $data);
    }

    public function room_kinds_create($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::where('id', $sanatorium_id)->first();
        $data['room_kinds'] = RoomKinds::where('status', 1)->get();
        $data['room_conditions'] = RoomConditions::where('status', 1)->get();
        return view('admin.sanatoriums.properties.room-kinds.room-kinds-create', $data);
    }

    public function room_kinds_store(Request $request, $sanatorium_id)
    {
        $srk = new Srk;
        $srk->sanatoriums_id = $sanatorium_id;
        $srk->room_kinds_id = $request->room_kinds_id;
        $srk->room_size = $request->room_size;
        $srk->bed_width = $request->bed_width;
        if ($srk->smoking == "on") {
            $srk->smoking = 1;
        } else {
            $srk->smoking = 0;
        }

        if ($request->file('main_image')) {
            $file = $request->file('main_image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('backend/images/sanatorium-features/room-kinds/'), $filename);
            $srk->main_image = $filename;
        }


        $srk->room_features = $request->room_features;

        $srk->room_amenities = json_encode($request->room_amenities);

        $srk->status = 1;
        $srk->save();


        $sws = new Sws;
        $sws->sanatoriums_id = $sanatorium_id;
        $sws->room_kinds_id = $request->room_kinds_id;
        $sws->room_count = 0;
        $sws->general_human_count = 0;
        $sws->older_count = 0;
        $sws->child_count = 0;
        $sws->possible_additional_beds = 0;
        $sws->status = 1;
        $sws->save();

        return redirect()->route('admin.sanatoriums.room-kinds', ['sanatorium_id' => $sanatorium_id])->with('success', 'Məlumatlar daxil edildi!');
    }

    public function check_room_kinds_status($id)
    {
        $kind = Srk::find($id);
        if ($kind['status'] == 1) {
            $kind->status = 0;
        } else {
            $kind->status = 1;
        }
        $kind->save();

        return "Status dəyişdirildi!";
    }

    public function edit_room_kind($id)
    {
        $data['room_kind'] = Srk::find($id);
        $data['room_kinds'] = RoomKinds::where('status', 1)->get();
        $data['room_conditions'] = RoomConditions::where('status', 1)->get();
        return view('admin.sanatoriums.properties.room-kinds.room-kinds-edit', $data);
    }

    public function update_room_kinds(Request $request, $id)
    {
        $srk = Srk::find($id);
        $srk->sanatoriums_id = $request->sanatoriums_id;
        $srk->room_kinds_id = $request->room_kinds_id;
        $srk->room_size = $request->room_size;
        $srk->bed_width = $request->bed_width;
        if ($srk->smoking == "on") {
            $srk->smoking = 1;
        } else {
            $srk->smoking = 0;
        }

        if ($request->file('main_image')) {
            $file = $request->file('main_image');
            $filename = date('YmdHi') . $file->getClientOriginalName();
            $file->move(public_path('backend/images/sanatorium-features/room-kinds/'), $filename);
            $srk->main_image = $filename;
        }


        $srk->room_features = $request->room_features;

        $srk->room_amenities = json_encode($request->room_amenities);

        $srk->save();


        return redirect()->route('admin.sanatoriums.room-kinds', ['sanatorium_id' => $request->sanatoriums_id])->with('success', 'Məlumatlar daxil edildi!');
    }


    public function penalty($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::where('id', $sanatorium_id)->first();
        $data['penalty'] = Penalties::where('sanatoriums_id', $sanatorium_id)->first();
        return view('admin.sanatoriums.properties.penalty', $data);
    }

    public function update_penalty(Request $request, $id)
    {
        $penalty = Penalties::where('sanatoriums_id', $id)->first();
        if (isset($penalty)) {
            $penalty->update($request->all());
        } else {
            Penalties::create($request->all());
        }
        return redirect()->back()->with('success', 'Məlumatlar yeniləndi!');
    }

    public function medical_bases($sanatoriums_id)
    {
        $data['sanatorium'] = Sanatoriums::where('id', $sanatoriums_id)->first();
        $data['medical_bases_elements'] = MedicalBaseElements::where('status', 1)->get();
        return view('admin.sanatoriums.properties.medical-base.medical-bases', $data);
    }

    public function element_available($element_id, $sanatorium_id)
    {
        $available = SmbElements::where('medical_base_elements_id', $element_id)->where('sanatoriums_id', $sanatorium_id)->first();
        if (isset($available)) {
            $available->delete();
            return "deleted";
        } else {
            SmbElements::create([
                'sanatoriums_id' => $sanatorium_id,
                'medical_base_elements_id' => $element_id
            ]);
            return "created";
        }
    }


    public function element_discount_available($element_id, $sanatorium_id)
    {
        $available = Sd::where('discounts_id', $element_id)->where('sanatoriums_id', $sanatorium_id)->first();
        if (isset($available)) {
            $available->delete();
            return "deleted";
        } else {
            Sd::create([
                'sanatoriums_id' => $sanatorium_id,
                'discounts_id' => $element_id
            ]);
            return "created";
        }
    }

    public function discount_options_create()
    {
        $data['discounts'] = Discounts::where('status', 1)->get();
        $data['room_kinds'] = RoomKinds::where('status', 1)->get();
        return view('admin.sanatoriums.properties.discount.create-discount', $data);
    }

    public function getDiscountOption($discount_id)
    {
        $room_kinds = RoomKinds::where('status', 1)->get();
        $html = '';

        if ($discount_id == 1) {
            $html .= '
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="start_date" class="form-label">Başlanğıc tarixi</label>
                    <input class="form-control" id="start_date" type="date" required name="start_date">
                </div>
            </div>
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="finish_date" class="form-label">Sonlanma tarixi</label>
                    <input class="form-control" id="finish_date" type="date" required name="finish_date">
                </div>
            </div>

        <div class="align-items-center mt-4 general-discount">
            <div class="row">
                <div class="col-4">
                    <select class="form-control" name="room_kinds_id[]">
                        <option disabled>Siyahıdan seçin</option>
                        <option value="all">Bütün otaqlar</option>';
            foreach ($room_kinds as $kind) {
                $html .=  '<option value="' . $kind['id'] . '">' . $kind['name'] . '</option>';
            }

            $html .= '</select>
                </div>

                <div class="col-4">
                    <div class="input-group">
                        <div class="input-group-text">%</div>
                        <input type="text" name="discount[]" required class="form-control" id="discount" placeholder="Endirim faizi daxil edin">
                    </div>
                </div>

                <div class="col-auto">
                    <button type="button" class="new-general-discount btn btn-outline-info waves-effect waves-light">
                        <span><i class="fas fa-plus"></i></span>
                        Yeni endirim
                    </button>
                </div>
            </div>
        </div>
            ';
        } elseif ($discount_id == 2) {
            $html .= '

            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="start_date" class="form-label">Başlanğıc tarixi</label>
                    <input class="form-control" id="start_date" type="date" required name="start_date">
                </div>
            </div>
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="finish_date" class="form-label">Sonlanma tarixi</label>
                    <input class="form-control" id="finish_date" type="date" required name="finish_date">
                </div>
            </div>

            <div class="align-items-center mt-4 day-discount">
            <div class="row">
                <div class="col-4">
                    <select class="form-control" name="room_kinds_id[]">
                        <option disabled>Siyahıdan seçin</option>
                        <option value="all">Bütün otaqlar</option>';
            foreach ($room_kinds as $kind) {
                $html .=  '<option value="' . $kind['id'] . '">' . $kind['name'] . '</option>';
            }

            $html .= '</select>
                </div>

                <div class="col-2">
                    <div class="input-group">
                        <div class="input-group-text" id="min_night">Gecədən</div>
                        <input type="text" name="min_night" class="form-control" id="min_night">
                    </div>
                </div>

                <div class="col-2">
                    <div class="input-group">
                        <div class="input-group-text">Gecəyə</div>
                        <input type="text" name="max_night" class="form-control" id="max_night">
                    </div>
                </div>

                <div class="mt-3">
                    <div class="form-check">
                        <input type="radio" name="depending_number_of_person" value="0" class="form-check-input radio_number_of_person" id="customCheck1">
                        <label class="form-check-label" value="1" for="customCheck1">Check this custom checkbox</label>
                    </div>
                    <div class="form-check">
                        <input type="radio" name="depending_number_of_person" class="form-check-input radio_number_of_person" id="customCheck2">
                        <label class="form-check-label" for="customCheck2">Check this custom checkbox</label>
                    </div>
                </div>

                <div class="col-4 mt-2 number_of_person">
                    <div class="input-group">
                        <div class="input-group-text">
                            <span>
                                <i class="fas fa-user"></i>
                            </span>
                        </div>
                        <input type="text" name="number_of_person" class="form-control" id="discount" placeholder="Say daxil edin">
                    </div>
                </div>

                <div class="col-4 mt-2">
                    <input type="text" name="free_night" class="form-control" id="discount" placeholder="Gecə sayını daxil edin">
                </div>



            </div>
        </div>';
        } elseif ($discount_id == 3) {
            $html .= '

            <div class="col-xl-4 mt-2">
            <div class="mb-3 mb-xl-0">
                <label for="start_date" class="form-label">Başlanğıc tarixi</label>
                <input class="form-control" id="start_date" type="date" required name="start_date">
            </div>
        </div>
        <div class="col-xl-4 mt-2">
            <div class="mb-3 mb-xl-0">
                <label for="finish_date" class="form-label">Sonlanma tarixi</label>
                <input class="form-control" id="finish_date" type="date" required name="finish_date">
            </div>
        </div>
            <div class="align-items-center mt-4 before-day-discount">

            <div class="row">
                <div class="col-md-12">
                <div class="col-3">
                    <label for="before_reserv_day">Gün daxil edin</label>
                    <input type="text" name="before_reserv_day" class="form-control" id="before_reserv_day">

                </div>
                </div>
            </div>

            <div class="row mt-2">

                <div class="col-4">
                    <select class="form-control" name="room_kinds_id[]">
                        <option disabled>Siyahıdan seçin</option>
                        <option value="all">Bütün otaqlar</option>';
            foreach ($room_kinds as $kind) {
                $html .= '<option value="' . $kind['id'] . '">' . $kind['name'] . '</option>';
            }

            $html .= '
                    </select>
                </div>

                <div class="col-4">
                    <div class="input-group">
                        <div class="input-group-text">%</div>
                        <input type="text" name="discount[]" required class="form-control" id="discount" placeholder="Endirim faizi daxil edin">
                    </div>
                </div>

                <div class="col-auto">
                    <button type="button" class="new-before-reserv-day-discount btn btn-outline-info waves-effect waves-light">
                        <span><i class="fas fa-plus"></i></span>
                        Yeni endirim
                    </button>
                </div>
            </div>
        </div>';
        } elseif ($discount_id == 4) {
            $html .= '

            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="start_date" class="form-label">Başlanğıc tarixi</label>
                    <input class="form-control" id="start_date" type="date" required name="start_date">
                </div>
            </div>
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="finish_date" class="form-label">Sonlanma tarixi</label>
                    <input class="form-control" id="finish_date" type="date" required name="finish_date">
                </div>
            </div>
            <div class="align-items-center mt-4 lie-discount">

            <div class="row mt-2">

                <div class="col-4">
                    <select class="form-control" name="room_kinds_id[]">
                        <option disabled>Siyahıdan seçin</option>
                        <option value="all">Bütün otaqlar</option>';
            foreach ($room_kinds as $kind) {
                $html .= '<option value="' . $kind['id'] . '">' . $kind['name'] . '</option>';
            }

            $html .= '
                    </select>
                </div>

                <div class="col-4">
                    <div class="input-group">
                        <div class="input-group-text">%</div>
                        <input type="text" name="discount[]" required class="form-control" id="discount" placeholder="Endirim faizi daxil edin">
                    </div>
                </div>

                <div class="col-auto">
                    <button type="button" class="new-lie-discount btn btn-outline-info waves-effect waves-light">
                        <span><i class="fas fa-plus"></i></span>
                        Yeni endirim
                    </button>
                </div>
            </div>
        </div>';
        } elseif ($discount_id == 5) {
            $html .= '
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="start_date" class="form-label">Başlanğıc tarixi</label>
                    <input class="form-control" id="start_date" type="date" required name="start_date">
                </div>
            </div>
            <div class="col-xl-4 mt-2">
                <div class="mb-3 mb-xl-0">
                    <label for="finish_date" class="form-label">Sonlanma tarixi</label>
                    <input class="form-control" id="finish_date" type="date" required name="finish_date">
                </div>
            </div>
            <div class="align-items-center mt-4 reserv-discount">

            <div class="row">
                <div class="col-3">
                    <label for="min_night">Minimum gecə</label>
                    <input type="text" name="min_night" class="form-control" id="min_night">
                </div>

                <div class="col-3">
                    <label for="max_night">Maksimum gecə</label>
                    <input type="text" name="max_night" class="form-control" id="max_night">
                </div>
            </div>

            <div class="row mt-4">

                <div class="col-4">
                    <select class="form-control" name="room_kinds_id[]">
                        <option disabled>Siyahıdan seçin</option>
                        <option value="all">Bütün otaqlar</option>';
            foreach ($room_kinds as $kind) {
                $html .= '<option value="' . $kind['id'] . '">' . $kind['name'] . '</option>';
            }

            $html .= '
                    </select>
                </div>

                <div class="col-4">
                    <div class="input-group">
                        <div class="input-group-text">%</div>
                        <input type="text" name="discount[]" required class="form-control" id="discount" placeholder="Endirim faizi daxil edin">
                    </div>
                </div>

                <div class="col-auto">
                    <button type="button" class="new-reserv-discount btn btn-outline-info waves-effect waves-light">
                        <span><i class="fas fa-plus"></i></span>
                        Yeni endirim
                    </button>
                </div>
            </div>
        </div>';
        }

        return $html;
    }

    public function save_discount_options(Request $request)
    {
        $discount_option_select = DiscountOptions::where('sanatoriums_id', $request->sanatoriums_id)
            ->where('discounts_id', $request->discounts_id)
            ->where('room_kinds_id', $request->room_kinds_id)
            ->latest()->first();
        if (!empty($discount_option_select) and ($request->start_date < $discount_option_select['finish_date'])) {
            return redirect()->back()->withInput($request->all());
        } else {
            for ($i = 0; $i < count($request->room_kinds_id); $i++) {
                $discount_options = new DiscountOptions();
                $discount_options->sanatoriums_id = $request->sanatoriums_id;
                $discount_options->discounts_id = $request->discounts_id;
                if ($request->room_kinds_id[$i] == "all") {
                    $discount_options->room_kinds_id = NULL;
                    $discount_options->all_rooms = 1;
                } else {
                    $discount_options->room_kinds_id = $request->room_kinds_id[$i];
                    $discount_options->all_rooms = 0;
                }
                $discount_options->start_date = $request->start_date;
                $discount_options->finish_date = $request->finish_date;
                $discount_options->discount = (isset($request->discount[$i])) ? $request->discount[$i] : NULL;
                $discount_options->min_night = (isset($request->min_night[$i])) ? $request->min_night[$i] : NULL;
                $discount_options->max_night = (isset($request->max_night[$i])) ? $request->max_night[$i] : NULL;
                if ($request->depending_number_of_person == "on") {
                    $discount_options->depending_number_of_person = 1;
                    $discount_options->number_of_person = NULL;
                } else {
                    $discount_options->depending_number_of_person = 0;
                    $discount_options->number_of_person = $request->number_of_person;
                }
                $discount_options->free_night = (isset($request->free_night)) ? $request->free_night : NULL;
                $discount_options->before_reserv_day = (isset($request->before_reserv_day)) ? $request->before_reserv_day : NULL;
                $discount_options->save();
            }
        }

        return redirect()->route('admin.discount', ['sanatorium_id' => $request->sanatoriums_id])->with('success', 'Məlumatlar daxil edildi!');
    }

    public function sccs($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::find($sanatorium_id);
        return view('admin.sanatoriums.properties.cards.cards', $data);
    }

    public function check_credit_cards_status($id)
    {
        $card = Sccs::find($id);
        if ($card['status'] == 1) {
            $card->status = 0;
        } else {
            $card->status = 1;
        }
        $card->save();

        return "Status dəyişdirildi!";
    }

    public function sccs_create($sanatorium_id)
    {
        $data['sanatorium'] = Sanatoriums::where('id', $sanatorium_id)->first();
        $data['cards']      = CreditCards::where('status', 1)->get();
        return view('admin.sanatoriums.properties.cards.create-cards', $data);
    }

    public function sccs_store(Request $request, $sanatorium_id)
    {
        $card = new Sccs();
        $card->sanatoriums_id = $request->sanatoriums_id;
        $card->start_date = $request->start_date;
        $card->finish_date = $request->finish_date;
        $card->credit_cards_id = json_encode($request->credit_cards_id);
        $card->cvv_available = ($request->cvv_available == "on") ? 1 : 0;
        $card->status = 1;
        $card->save();
        return redirect()->route('admin.sanatoriums.sanatorium-credit-cards', ['sanatorium_id' => $sanatorium_id])->with('success', 'Məlumatlar daxil edildi!');
    }

    public function edit_sccs($sanatorium_id, $card_id)
    {
        $data['sanatorium']         = Sanatoriums::where('id', $sanatorium_id)->first();
        $data['cards']              = CreditCards::where('status', 1)->get();
        $data['card']               = Sccs::where('sanatoriums_id', $sanatorium_id)->where('id', $card_id)->first();
        return view('admin.sanatoriums.properties.cards.edit-cards', $data);
    }

    public function update_sccs(Request $request, $sanatorium_id, $card_id)
    {
        $card = Sccs::find($card_id);
        $card->sanatoriums_id = $sanatorium_id;
        $card->start_date = $request->start_date;
        $card->finish_date = $request->finish_date;
        $card->credit_cards_id = json_encode($request->credit_cards_id);
        $card->cvv_available = ($request->cvv_available == "on") ? 1 : 0;
        $card->status = 1;
        $card->save();
        return redirect()->route('admin.sanatoriums.sanatorium-credit-cards', ['sanatorium_id' => $sanatorium_id])->with('success', 'Məlumatlar dəyişdirildi!');
    }

    //wizarts
    public function wizarts($sanatorium_id)
    {
        $data['sanatorium']   = Sanatoriums::where('id', $sanatorium_id)->first();
        $wizart = $data['sanatorium']->getSws->first()->optional;
        $data['decode'] = json_decode($wizart);
        $data['srk'] = Srk::where('sanatoriums_id', $sanatorium_id)->get();
        return view('admin.sanatoriums.properties.wizart.wizarts', $data);
    }

    public function check_wizarts_status($id)
    {
        $wizart = Sws::find($id);
        if ($wizart['status'] == 1) {
            $wizart->status = 0;
        } else {
            $wizart->status = 1;
        }
        $wizart->save();

        return "Status dəyişdirildi!";
    }

    public function save_wizart_optional(Request $request, $sanatorium_id)
    {
        $html = '';
        for($i=0; $i < count($request->start_day); $i++)
        {
            $html .= '{"start_day:"'.$request->start_day[$i].'","end_day:"'.$request->end_day[$i].'}';
        }
        Sws::where('sanatoriums_id', $sanatorium_id)->update(['optional' => json_encode($request->except('_token'))]);
        return redirect()->back()->with('success', "Salam");
    }

    public function change_week_or_day($sanatorium_id, $w_or_d)
    {
        
        if($w_or_d==0)
        {
            $content = "Qiymət cədvəli \"Günlük\" olaraq dəyişdirildi. ";
            Sws::where('sanatoriums_id', $sanatorium_id)->update(['w_or_d' => $w_or_d, 'optional' => NULL]);
        }
        elseif($w_or_d==1)
        {
            $content = "Qiymət cədvəli \"Həftəlik\" olaraq dəyişdirildi. ";
            Sws::where('sanatoriums_id', $sanatorium_id)->update(['w_or_d' => $w_or_d, 'optional'=> NULL]);
        }
        else
        {
            $content = "Qiymət cədvəli \"İstəyə bağlı\" olaraq dəyişdirildi. ";
            Sws::where('sanatoriums_id', $sanatorium_id)->update(['w_or_d' => $w_or_d]);
        }
        return $content;
    }

    public function change_room_count($sanatorium_id,$room_kinds_id,$value)
    {
        Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['room_count' => $value]);

        return getRoomName($room_kinds_id).' üçün ümumi otaq sayı '.$value.' olaraq dəyişdirildi';
    }

    public function change_general_human_count($sanatorium_id,$room_kinds_id,$value)
    {
        $sws_check = Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->first();
        if($value<$sws_check->older_count+$sws_check->child_count){
            return "Ümumi nəfər sayı böyük və kiçik nəfərlərin sayı cəmindən kiçik ola bilməz.";
        }
        else
        {
            Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['general_human_count' => $value]);
            return getRoomName($room_kinds_id).' üçün ümumi nəfər sayı '.$value.' olaraq dəyişdirildi';
        }

    }

    public function change_minimum_human_count($sanatorium_id,$room_kinds_id,$value)
    {
        $sws_check = Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->first();
        if($value>$sws_check->older_count+$sws_check->child_count){
            return "Minimum nəfər sayı böyük və kiçik nəfərlərin sayı cəmindən böyük ola bilməz.";
        }
        else
        {
            Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['minimum_human_count' => $value]);
            return getRoomName($room_kinds_id).' üçün minimum nəfər sayı '.$value.' olaraq dəyişdirildi';
        }

    }

    public function change_older_count($sanatorium_id,$room_kinds_id,$value)
    {
        $sws_check = Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->first();
        if($value>$sws_check->general_human_count-$sws_check->child_count){
            return "Böyük nəfər sayı ümumi və kiçik nəfərlərin sayı fərqindən böyük ola bilməz.";
        }
        else
        {
            Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['older_count' => $value]);
            return getRoomName($room_kinds_id).' üçün böyük nəfər sayı '.$value.' olaraq dəyişdirildi';
        }
    }

    public function change_child_count($sanatorium_id,$room_kinds_id,$value)
    {
        $sws_check = Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->first();
        if($value>$sws_check->general_human_count-$sws_check->older_count){
            return "Kiçik nəfər sayı ümumi və böyük nəfərlərin sayı fərqindən böyük ola bilməz.";
        }
        else
        {
            Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['child_count' => $value]);
            return getRoomName($room_kinds_id).' üçün kiçik nəfər sayı '.$value.' olaraq dəyişdirildi';
        }
    }

    public function change_possible_additional_beds($sanatorium_id,$room_kinds_id,$value)
    {
        Sws::where('sanatoriums_id', $sanatorium_id)->where('room_kinds_id', $room_kinds_id)->update(['possible_additional_beds' => $value]);
        return getRoomName($room_kinds_id).' üçün əlavə oluna biləcək maksimum yataq sayı '.$value.' olaraq dəyişdirildi';
    }


    public function children($sanatorium_id)
    {
        $data['sanatorium']   = Sanatoriums::where('id', $sanatorium_id)->first();
        return view('admin.sanatoriums.properties.children.children', $data);
    }

    public function stchild_store(Request $request, $sanatorium_id)
    {
        Stchild::where('sanatoriums_id', $sanatorium_id)->delete();
        for ($i=0;$i<count($request->min_age);$i++)
        {
            Stchild::create([
                'sanatoriums_id'        =>$sanatorium_id,
                'child_is_accepted'     =>$request->child_is_accepted,
                'min_age'               =>$request->min_age[$i],
                'max_age'               =>$request->max_age[$i],
                'paid_or_not'           =>$request->paid_or_not[$i]
            ]);
        }
        return redirect()->route('admin.sanatoriums.children', ['sanatorium_id'=>$sanatorium_id])->with('success', 'Müalicəli - yaş limiti üçün məlumatlar yeniləndi!');
    }

    public function stoutchild_store(Request $request, $sanatorium_id)
    {
        Stoutchild::where('sanatoriums_id', $sanatorium_id)->delete();
        for ($i=0;$i<count($request->min_age);$i++)
        {
            Stoutchild::create([
                'sanatoriums_id'            =>$sanatorium_id,
                'out_child_is_accepted'     =>$request->out_child_is_accepted,
                'min_age'                   =>$request->min_age[$i],
                'max_age'                   =>$request->max_age[$i],
                'paid_or_not'               =>$request->paid_or_not[$i]
            ]);
        }
        return redirect()->route('admin.sanatoriums.children', ['sanatorium_id'=>$sanatorium_id])->with('success', 'Müalicəsiz - yaş limiti üçün məlumatlar yeniləndi!');
    }

    public function comments($sanatorium_id)
    {
        $data['sanatorium']   = Sanatoriums::where('id', $sanatorium_id)->first();
        return view('admin.sanatoriums.properties.comments.comments', $data);
    }

    public function comments_create($sanatium_id)
    {

    }

    public function price($sanatorium_id)
    {
        $data['sanatorium']   = Sanatoriums::where('id', $sanatorium_id)->first();
        
        return view('admin.sanatoriums.properties.price.price', $data);
    }

}
